package br.edu.ifsp.scl.ads.pdm.sharedlist.controller

import br.edu.ifsp.scl.ads.pdm.sharedlist.model.Task
import br.edu.ifsp.scl.ads.pdm.sharedlist.model.TaskDAO
import br.edu.ifsp.scl.ads.pdm.sharedlist.model.TaskFirebaseDAO
import br.edu.ifsp.scl.ads.pdm.sharedlist.view.MainActivity

class TaskController (private val mainActivity: MainActivity){
    private val taskDaoImpl: TaskDAO = TaskFirebaseDAO()

    fun insertTask(task: Task) {
        Thread {
            taskDaoImpl.createTask(task)
        }.start()
    }
    fun getTask(id: Int) = taskDaoImpl.retrieveTask(id)
    fun getTasks() {
        Thread {
            val list = taskDaoImpl.retrieveTasks()
            mainActivity.runOnUiThread {
                mainActivity.updateTaskList(list)
            }
        }.start()
    }
    fun editTask(task: Task) {
        Thread {
            taskDaoImpl.updateTask(task)
        }.start()
    }
    fun removeTask(task: Task) {
        Thread {
            taskDaoImpl.deleteTask(task)
        }.start()
    }
    fun countTasks(title: String) = taskDaoImpl.countTasks(title)

}