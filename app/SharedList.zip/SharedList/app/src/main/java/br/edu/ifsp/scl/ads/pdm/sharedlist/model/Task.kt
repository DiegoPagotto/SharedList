package br.edu.ifsp.scl.ads.pdm.sharedlist.model

import android.os.Parcelable
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.parcelize.Parcelize

@Parcelize
@Entity
class Task (
    @PrimaryKey(autoGenerate = true) val id: Int? = -1,
    var title: String = "",
    var description: String = "",
    var dateCreate: String = "",
    var datePreviousFinish: String = "",
    var user: String = "",
    var isCompleted: Boolean = false,
    var userConcluded: String = "",
): Parcelable